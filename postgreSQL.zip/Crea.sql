DROP TABLE IF EXISTS usuarios CASCADE;
CREATE TABLE usuarios (
  username VARCHAR(255) NOT NULL,
  role VARCHAR(255) NULL,
  organizacion VARCHAR(255) NULL,
  PRIMARY KEY(username)
);

DROP TABLE IF EXISTS tipos CASCADE;
CREATE TABLE tipos (
  tipo VARCHAR(255) NOT NULL,
  vmax integer NULL,
  PRIMARY KEY(tipo)
);

DROP TABLE IF EXISTS vehiculos CASCADE;
CREATE TABLE vehiculos (
  matricula VARCHAR(255) NOT NULL,
  tipos_tipo VARCHAR(255) NOT NULL,

  PRIMARY KEY(matricula),
  
  FOREIGN KEY(tipos_tipo)
    REFERENCES tipos(tipo)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION
);


DROP TABLE IF EXISTS datos CASCADE;
CREATE TABLE datos (
  id integer NOT NULL,
  vehiculos_matricula VARCHAR(255) NOT NULL,
  velocidad FLOAT NULL,
  latitud FLOAT NULL,
  longitud FLOAT NULL,

  PRIMARY KEY(id),
 
  FOREIGN KEY(vehiculos_matricula)
    REFERENCES vehiculos(matricula)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION
);

DROP TABLE IF EXISTS usuarios_has_vehiculos CASCADE;
CREATE TABLE usuarios_has_vehiculos (
  usuarios_username VARCHAR(255) NOT NULL,
  vehiculos_matricula VARCHAR(255) NOT NULL,
  
  PRIMARY KEY(usuarios_username, vehiculos_matricula),
  
  FOREIGN KEY(usuarios_username)
    REFERENCES usuarios(username)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION,
  FOREIGN KEY(vehiculos_matricula)
    REFERENCES vehiculos(matricula)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION
);


