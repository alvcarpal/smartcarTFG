/*
Clase creada para hacer peticiones mediante
Jersey
 */


package com.example.locationappv2;

import android.util.Log;
import android.widget.TextView;

import java.text.BreakIterator;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.client.Entity;

public class comunicacionIoT {

    public comunicacionIoT() {

    }

    public void generarContexInfo(String latitud, String longitud){

        // Generamos un número aleatorio acotado para la velocidad
        Double velocidad;
        velocidad=Math.random()*(120-60)+60;

        // Creamos la entidad correspondiente, en caso de existir se nos indicará que ha habido un conflicto
        Client client = ClientBuilder.newClient();
        Entity payload = Entity.text("lat|"+latitud+"|lon|"+longitud+"|vel|"+velocidad);
        Response response = client.target("http://192.168.0.33:7896/iot/d?k=4jggokgpepnvsb2uv4s40d59ov&i=Sensor001")
                .request(MediaType.TEXT_PLAIN_TYPE)
                .post(payload);
    }
}
